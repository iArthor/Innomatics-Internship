from google import genai
import os
from dotenv import load_dotenv

load_dotenv()

class GeminiService:
    def __init__(self):
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            raise ValueError("GEMINI_API_KEY not found")

        # ✅ NEW CLIENT
        self.client = genai.Client(api_key=api_key)

        # ✅ USE A MODEL YOU SAW IN list_models
        self.model = "models/gemini-flash-latest"

    def generate_response(self, prompt: str) -> str:
        try:
            response = self.client.models.generate_content(
                model=self.model,
                contents=prompt
            )
            return response.text
        except Exception as e:
            return f"❌ Gemini Error: {e}"