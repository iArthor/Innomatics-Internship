SYSTEM_PROMPT = """
You are a professional Career Advisor chatbot.

Rules:
- Only answer career-related questions
- Provide structured and actionable advice
- Ask clarifying questions when required
- Do NOT answer medical or legal questions
"""

def build_prompt(chat_history, user_input):
    prompt = SYSTEM_PROMPT + "\n\n"
    for msg in chat_history:
        prompt += f"{msg['role'].upper()}: {msg['content']}\n"
    prompt += f"USER: {user_input}\nASSISTANT:"
    return prompt