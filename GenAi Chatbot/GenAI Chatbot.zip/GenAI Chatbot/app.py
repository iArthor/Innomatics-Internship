from dotenv import load_dotenv
load_dotenv()

import os
print("API KEY LOADED:", os.getenv("GEMINI_API_KEY"))

import streamlit as st
from services.gemini_service import GeminiService
from memory.session_memory import init_memory, add_message, get_chat_history
from config.prompts import build_prompt

st.set_page_config(page_title="Career Advisor Bot")

st.title("💼 Career Advisor Chatbot")

init_memory()
gemini = GeminiService()

for msg in get_chat_history():
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

user_input = st.chat_input("Ask your career question")

if user_input:
    add_message("user", user_input)

    prompt = build_prompt(get_chat_history(), user_input)

    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            response = gemini.generate_response(prompt)
            st.markdown(response)

    add_message("assistant", response)