from youtube_transcript_api import YouTubeTranscriptApi

def extract_video_id(url):
    return url.split("v=")[-1]

def get_transcript(video_id):
    api = YouTubeTranscriptApi()
    transcript = api.fetch(video_id)

    text = " ".join([i.text for i in transcript])
    return text