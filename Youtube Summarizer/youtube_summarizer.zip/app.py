import streamlit as st
from transcript import get_transcript, extract_video_id
from summarizer import summarize_text

st.title("🎥 YouTube Video Summarizer (Gemini)")

url = st.text_input("Enter YouTube URL")

if st.button("Summarize"):
    if url:
        video_id = extract_video_id(url)

        with st.spinner("Fetching transcript..."):
            text = get_transcript(video_id)

        with st.spinner("Summarizing..."):
            summary = summarize_text(text)

        st.subheader("Summary")
        st.write(summary)
    else:
        st.warning("Please enter a valid URL")