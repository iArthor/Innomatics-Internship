from google import genai
import os
from dotenv import load_dotenv

load_dotenv()

client = genai.Client(api_key=os.getenv("AIzaSyCcq6jDAtKQdW-cQgOFIzN5vaFA0KOCun0"))

def summarize_text(text):
    response = client.models.generate_content(
        model="gemini-2.5-flash",
        contents=f"Summarize in bullet points:\n{text[:3000]}"
    )
    return response.text